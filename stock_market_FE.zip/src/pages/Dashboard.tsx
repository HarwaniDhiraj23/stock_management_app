import { Box } from "@material-ui/core";
import React from "react";
import Layout from "../common_component/Layout.tsx";

function Dashboard() {
  return (
    <Layout>
      <Box>DashBoard</Box>
    </Layout>
  );
}

export default Dashboard;

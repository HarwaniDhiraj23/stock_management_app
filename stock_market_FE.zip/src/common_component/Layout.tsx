import { Box, Typography } from "@material-ui/core";
import React, { useState } from "react";
import Sidebar from "./Sidebar.tsx";
import Navbar from "./Navbar.tsx";

function Layout({ children }) {
  const [open, setOpen] = useState(true);
  const handleDrawerOpen = () => {
    setOpen(!open);
  };

  return (
    <Box
      style={{
        display: "flex",
        height: "100vh",
        overflow: "hidden",
      }}
    >
      <Sidebar open={open} />
      <Box
        style={{
          display: "flex",
          flexDirection: "column",
          flex: 1,
          transition: "margin-left 0.3s",
          overflow: "auto",
        }}
      >
        <Navbar SideBarOpen={open} handleDrawerOpen={handleDrawerOpen} />
        <Box
          style={{
            paddingLeft: "20px",
            paddingRight: "20px",
            flex: 1,
          }}
        >
          {children}
        </Box>
        <Box
          style={{
            display: "flex",
            alignContent: "center",
            justifyContent: "space-between",
            border: "1px solid white",
            padding: "50px",
            borderRadius: "10px",
            marginTop: "15px",
            backgroundColor: "#FFFFFF",
            marginLeft: "20px",
            marginRight: "20px",
            marginBottom: "20px",
          }}
        >
          <Typography>© 2019-2024 StockIO</Typography>
          <Box style={{ display: "flex", alignItems: "center", gap: 20 }}>
            <Typography>About</Typography>
            <Typography>Themes</Typography>
            <Typography>Blog</Typography>
            <Typography>Contact</Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}

export default Layout;

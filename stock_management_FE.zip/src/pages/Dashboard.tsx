import {
  Box,
  Button,
  Divider,
  Grid,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  styled,
} from "@material-ui/core";
import React, { useEffect, useState } from "react";
import Layout from "../common_component/Layout.tsx";
import LineChart from "../common_component/LineChart.tsx";
import ToggleButton from "@material-ui/lab/ToggleButton";
import ToggleButtonGroup from "@material-ui/lab/ToggleButtonGroup";
import StockApi from "../service/stock-service.ts";
import {
  ArrowDownward,
  ArrowUpward,
  ExpandLess,
  ExpandMore,
  Sms,
} from "@material-ui/icons";
import { classes } from "istanbul-lib-coverage";

const MainBox = styled(Box)({
  backgroundColor: "#ACEBFD",
  padding: "20px",
  margin: "10px",
  borderRadius: "10px",
});

const HeaderBox = styled(Box)({
  display: "flex",
  flexDirection: "row",
  alignItems: "center",
  justifyContent: "space-between",
});

const StockTitle = styled(Typography)({
  fontWeight: "bold",
});

const StockStatus = styled(Typography)({
  display: "flex",
});

const ToggleButtonGroupStyled = styled(ToggleButtonGroup)({
  height: "30px",
});

const StatusSpan = styled("span")(({ status }: any) => ({
  color: status === "high" ? "green" : "red",
  display: "flex",
  flexDirection: "row",
  alignItems: "center",
}));

const ToggleButtonStyled = styled(ToggleButton)(
  ({ alignment, period }: any) => ({
    backgroundColor: alignment === period ? "red" : "#00A1CE",
    "& .MuiToggleButton-label": {
      color: "black",
    },
  })
);

const ChartBox = styled(Box)({
  flex: 1,
  display: "flex",
  backgroundColor: "#FFFFFF",
  borderRadius: "10px",
});
const TableRateValue = styled(Box)({
  alignItems: "center",
  display: "flex",
  justifyContent: "flex-end",
});

const profiles = [
  { name: "Chris Wood", role: "Graphic Designer", salary: "$1834" },
  { name: "Alex Johnson", role: "Web Developer", salary: "$2100" },
  { name: "Jane Doe", role: "UI/UX Designer", salary: "$1950" },
  { name: "Michael Smith", role: "Project Manager", salary: "$2500" },
  { name: "Jane Doe", role: "UI/UX Designer", salary: "$1950" },
  { name: "Michael Smith", role: "Project Manager", salary: "$2500" },
  { name: "Alex Johnson", role: "Web Developer", salary: "$2100" },
];

const teamMembers = [
  {
    name: "Chris Wood",
    status: "Online",
    action: (
      <Button>
        <Sms />
        Invite
      </Button>
    ),
  },
  {
    name: "Alex Johnson",
    status: "Online",
    action: (
      <Button>
        <Sms />
        Message
      </Button>
    ),
  },
  {
    name: "Jane Doe",
    status: "Online",
    action: (
      <Button>
        <Sms />
        Invite
      </Button>
    ),
  },
  {
    name: "Michael Smith",
    status: "Online",
    action: (
      <Button>
        <Sms />
        Message
      </Button>
    ),
  },
];
function createData(Name: string, View: string, Value: string, Rate: any) {
  return { Name, View, Value, Rate };
}

const rows = [
  createData(
    "/demo/admin/index.html",
    "4.525",
    "$255",
    <TableRateValue>
      <ArrowDownward style={{ color: "red" }} /> 42.22%
    </TableRateValue>
  ),
  createData(
    "/demo/admin/forms.html",
    "2.987",
    "$139",
    <TableRateValue>
      <ArrowUpward style={{ color: "green" }} /> 12.02%
    </TableRateValue>
  ),
  createData(
    "/demo/admin/util.html",
    "2.844",
    "$124",
    <TableRateValue>
      <ArrowDownward style={{ color: "red" }} /> 86.20%
    </TableRateValue>
  ),
  createData(
    "/demo/admin/validation.html",
    "1.22",
    "$55",
    <TableRateValue>
      <ArrowDownward style={{ color: "red" }} /> 01.22%
    </TableRateValue>
  ),
  createData(
    "/demo/admin/modals.html",
    "505",
    "$3",
    <TableRateValue>
      <ArrowUpward style={{ color: "green" }} /> 08.99%
    </TableRateValue>
  ),
];

function Dashboard() {
  const [showSales, setSales] = useState<any>([]);
  const [alignment, setAlignment] = useState<string>("day");

  useEffect(() => {
    const fetchData = async () => {
      const result = await StockApi.getRandomStock();
      setSales(result.data.data);
    };
    fetchData();
  }, []);

  const handleAlignment = (
    _event: React.MouseEvent<HTMLElement>,
    newAlignment: string
  ) => {
    setAlignment(newAlignment);
  };

  const labels = {
    day: showSales[0]?.day,
    week: showSales[0]?.week,
    month: showSales[0]?.month,
    year: showSales[0]?.year,
  };

  const values = {
    day: showSales[0]?.day_value,
    week: showSales[0]?.week_value,
    month: showSales[0]?.month_value,
    year: showSales[0]?.year_value,
  };

  const data = {
    labels: labels[alignment],
    datasets: [
      {
        label: showSales[0]?.stock_name,
        data: values[alignment],
        borderColor: "#17A5CE",
        backgroundColor: "#17A5CE",
        fill: true,
        tension: 0.1,
        pointBackgroundColor: "#17A5CE",
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
        pointRadius: 7,
      },
    ],
  };

  const generateBarData = (index: number) => ({
    labels: showSales[index]?.day,
    datasets: [
      {
        label: showSales[index]?.stock_name,
        data: showSales[index]?.day_value,
        borderColor: "#17A5CE",
        backgroundColor: "#17A5CE",
        fill: true,
        tension: 0.1,
        pointBackgroundColor: "#17A5CE",
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
        pointRadius: 7,
      },
    ],
  });

  return (
    <Layout>
      <MainBox>
        <HeaderBox>
          <Box>
            <Typography variant="h6">Sales Value</Typography>
            <StockTitle variant="h5">${showSales[0]?.current_value}</StockTitle>
            <StockStatus variant="body2">
              Yesterday{" "}
              <StatusSpan status={showSales[0]?.status}>
                {showSales[0]?.status === "high" ? (
                  <ExpandLess />
                ) : (
                  <ExpandMore />
                )}
                {showSales[0]?.average}%
              </StatusSpan>
            </StockStatus>
          </Box>
          <ToggleButtonGroupStyled
            value={alignment}
            exclusive
            onChange={handleAlignment}
            aria-label="text alignment"
          >
            {["day", "week", "month", "year"].map((period) => (
              <ToggleButtonStyled
                key={period}
                value={period}
                aria-label={`${period} aligned`}
                alignment={alignment}
                period={period}
              >
                {period.charAt(0).toUpperCase() + period.slice(1)}
              </ToggleButtonStyled>
            ))}
          </ToggleButtonGroupStyled>
        </HeaderBox>
        <LineChart data={data} chartType="line" labels={true} />
      </MainBox>
      <Box
        display="flex"
        flexDirection="row"
        alignItems="center"
        justifyContent="center"
        style={{
          gap: 10,
          marginLeft: "10px",
          marginRight: "10px",
          marginTop: "20px",
        }}
      >
        <Grid container spacing={2}>
          {[1, 2, 3].map((index) => (
            <Grid item xs={12} sm={12} md={6} lg={4} xl={2} key={index}>
              <ChartBox>
                <Box
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: "10px 0px 10px 10px",
                  }}
                >
                  <LineChart
                    data={generateBarData(index)}
                    chartType="line"
                    labels={false}
                    style={{ width: "150px" }}
                  />
                </Box>
                <Box
                  style={{
                    display: "flex",
                    alignItems: "left",
                    justifyContent: "center",
                    flexDirection: "column",
                    marginLeft: "10px",
                  }}
                >
                  <Typography variant="h6" style={{ fontWeight: "bold" }}>
                    ${showSales[index]?.current_value}
                  </Typography>
                  <Typography style={{ fontSize: "11px" }}>
                    {showSales[index]?.day[0]}-{showSales[index]?.day[9]}
                  </Typography>
                  <StockStatus style={{ fontSize: "13px" }}>
                    <StatusSpan status={showSales[index]?.status}>
                      {showSales[index]?.status === "high" ? (
                        <ExpandLess />
                      ) : (
                        <ExpandMore />
                      )}
                      {showSales[index]?.average}%
                    </StatusSpan>
                  </StockStatus>
                </Box>
              </ChartBox>
            </Grid>
          ))}
        </Grid>
      </Box>
      <Box margin={"10px"} style={{ display: "flex", gap: 10 }}>
        <Grid container spacing={2} style={{ marginTop: "20px" }}>
          <Grid item xs={12} sm={12} md={4}>
            <Box
              style={{
                backgroundColor: "#FFFFFF",
                borderRadius: "10px",
                display: "flex",
                flexDirection: "column",
                flex: 1,
                height: "600px",
              }}
            >
              <Typography
                variant="h6"
                style={{ paddingLeft: "20px", paddingTop: "10px" }}
              >
                Weekly Sales
              </Typography>
              <Typography
                variant="body2"
                style={{ paddingLeft: "20px", paddingBottom: "10px" }}
              >
                28 Daily Avg.
              </Typography>
              <Divider />
              <Box
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexDirection: "column",
                  flex: 1,
                }}
              >
                <Box
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexDirection: "column",
                    flex: "1",
                  }}
                >
                  <Typography variant="h3" style={{ fontWeight: "bold" }}>
                    $456,678
                  </Typography>
                  <Typography variant="body1">
                    Total Themesberg Sales
                  </Typography>
                  <Button
                    variant="contained"
                    style={{ color: "white", backgroundColor: "#1D2030" }}
                  >
                    Generate Report
                  </Button>
                </Box>
                <Box
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexDirection: "column",
                    flex: "1",
                  }}
                >
                  <LineChart data={data} chartType="bar" labels={false} />
                </Box>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={12} md={4}>
            <Box
              style={{
                backgroundColor: "#FFFFFF",
                borderRadius: "10px",
                display: "flex",
                flexDirection: "column",
                flex: 1,
                height: "600px",
              }}
            >
              <Typography
                variant="h6"
                style={{ padding: "20px", fontWeight: "bold" }}
              >
                Top Author Earnings
              </Typography>
              <Divider />
              <Box>
                {profiles.map((profile, index) => (
                  <>
                    <Box
                      style={{
                        padding: "10px",
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                    >
                      <Box style={{ display: "flex" }}>
                        <img
                          src="https://demo.themesberg.com/volt-pro-react/static/media/profile-picture-1.508e07ee.jpg"
                          alt="img"
                          style={{
                            width: "50px",
                            height: "50px",
                            borderRadius: "10px",
                            marginRight: "10px",
                          }}
                        />

                        <Box>
                          <Typography>{profile.name}</Typography>
                          <Typography variant="body2">
                            {profile.role}
                          </Typography>
                        </Box>
                      </Box>
                      <Box>
                        <Typography>{profile.salary}</Typography>
                      </Box>
                    </Box>
                    {index < profiles.length - 1 && (
                      <Divider style={{ margin: "0px 10px 0px 10px" }} />
                    )}
                  </>
                ))}
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={12} md={4}>
            <Box
              style={{
                backgroundColor: "#FFFFFF",
                borderRadius: "10px",
                display: "flex",
                flexDirection: "column",
                flex: 1,
                height: "600px",
              }}
            >
              <Box
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Typography
                  variant="h6"
                  style={{ padding: "20px", fontWeight: "bold" }}
                >
                  Notifications
                </Typography>
                <Typography
                  variant="h6"
                  style={{ padding: "20px", fontWeight: "bold" }}
                >
                  View All
                </Typography>
              </Box>
              <Divider />
            </Box>
          </Grid>
        </Grid>
      </Box>
      <Box
        style={{
          margin: "20px 10px 10px 10px",
          gap: 20,
          display: "flex",
          flexDirection: "row",
        }}
      >
        <Box
          style={{
            display: "flex",
            flex: 2,
            backgroundColor: "#F5F8FB",
            borderRadius: "10px",
            flexDirection: "column",
            gap: 20,
          }}
        >
          <Box width={"100%"} style={{ borderRadius: "10px" }}>
            <Box
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                backgroundColor: "#FFF",
                borderRadius: "10px 0px 10px 0px",
              }}
            >
              <Typography
                variant="h6"
                style={{ padding: "20px", fontWeight: "bold" }}
              >
                Page visits
              </Typography>
              <Button
                style={{
                  textTransform: "capitalize",
                  color: "#FFF",
                  backgroundColor: "#1D2030",
                  marginRight: "20px",
                  borderRadius: "10px",
                }}
              >
                See All
              </Button>
            </Box>
            <TableContainer component={Paper}>
              <Table aria-label="simple table">
                <TableHead style={{ backgroundColor: "#F2F4F6" }}>
                  <TableRow>
                    <TableCell>Page Name</TableCell>
                    <TableCell align="right">Page Views</TableCell>
                    <TableCell align="right">Page Value</TableCell>
                    <TableCell align="right">Bounce rate</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                    <TableRow key={row.Name}>
                      <TableCell component="th" scope="row">
                        {row.Name}
                      </TableCell>
                      <TableCell align="right">{row.View}</TableCell>
                      <TableCell align="right">{row.Value}</TableCell>
                      <TableCell align="right">{row.Rate}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
          <Box>
            <Box
              style={{
                backgroundColor: "#FFFFFF",
                borderRadius: "10px",
                display: "flex",
                flexDirection: "column",
                flex: 1,
                height: "600px",
              }}
            >
              <Typography
                variant="h6"
                style={{ padding: "20px", fontWeight: "bold" }}
              >
                Team members
              </Typography>
              <Divider />
              <Box>
                {teamMembers.map((profile, index) => (
                  <>
                    <Box
                      style={{
                        padding: "10px",
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                    >
                      <Box style={{ display: "flex" }}>
                        <img
                          src="https://demo.themesberg.com/volt-pro-react/static/media/profile-picture-1.508e07ee.jpg"
                          alt="img"
                          style={{
                            width: "50px",
                            height: "50px",
                            borderRadius: "10px",
                            marginRight: "10px",
                          }}
                        />

                        <Box>
                          <Typography>{profile.name}</Typography>
                          <Typography variant="body2">
                            {profile.status}
                          </Typography>
                        </Box>
                      </Box>
                      <Box>{profile.action}</Box>
                    </Box>
                    {index < profiles.length - 1 && (
                      <Divider style={{ margin: "0px 10px 0px 10px" }} />
                    )}
                  </>
                ))}
              </Box>
            </Box>
            <Box
              style={{
                backgroundColor: "#FFFFFF",
                borderRadius: "10px",
                display: "flex",
                flexDirection: "column",
                flex: 1,
              }}
            >
              <Typography
                variant="h6"
                style={{ padding: "20px", fontWeight: "bold" }}
              >
                Team members
              </Typography>
              <Divider />
              <Box>
                {teamMembers.map((profile, index) => (
                  <>
                    <Box
                      style={{
                        padding: "10px",
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                    >
                      <Box style={{ display: "flex" }}>
                        <img
                          src="https://demo.themesberg.com/volt-pro-react/static/media/profile-picture-1.508e07ee.jpg"
                          alt="img"
                          style={{
                            width: "50px",
                            height: "50px",
                            borderRadius: "10px",
                            marginRight: "10px",
                          }}
                        />

                        <Box>
                          <Typography>{profile.name}</Typography>
                          <Typography variant="body2">
                            {profile.status}
                          </Typography>
                        </Box>
                      </Box>
                      <Box>{profile.action}</Box>
                    </Box>
                    {index < profiles.length - 1 && (
                      <Divider style={{ margin: "0px 10px 0px 10px" }} />
                    )}
                  </>
                ))}
              </Box>
            </Box>
          </Box>
        </Box>
        <Box
          style={{
            display: "flex",
            flex: 1,
            backgroundColor: "cyan",
            borderRadius: "10px",
          }}
        ></Box>
      </Box>
    </Layout>
  );
}

export default Dashboard;

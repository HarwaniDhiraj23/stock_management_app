export const BASE_URL = `http://localhost:3001/api/v1/`;

export const RESPONSE_TYPE = "json";

export const CONTENT_TYPE = "application/json";

export const MULTIPART_CONTENT_TYPE = "multipart/form-data";

export const drawerWidth = 230;
export const closedDrawerWidth = 72;